# -*- conding: utf-8 -*-
"""fichero de configuración del Flask-WTF"""
WTF_CSRF_ENABLED = True
SECRET_KEY = 'losmagnificos'

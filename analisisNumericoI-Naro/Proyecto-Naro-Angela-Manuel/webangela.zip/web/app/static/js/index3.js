var container = document.getElementById('prgs');
var machine = document.getElementById('machine');
setTimeout(function(){
  container.classList.add('hide');
  machine.classList.add('show');
},10000);
var s1= document.getElementById('s1');
var s2= document.getElementById('s2');
var s3= document.getElementById('s3');
var s4= document.getElementById('s4');
var s5= document.getElementById('s5');
var s6= document.getElementById('s6');
var s7= document.getElementById('s7');
var s8= document.getElementById('s8');
setTimeout(function(){
	s1.classList.add('hide');
},25000);
setTimeout(function(){
	s2.classList.add('hide');
},30000);
setTimeout(function(){
	s3.classList.add('hide');
},35000);
setTimeout(function(){
	s4.classList.add('hide');
},40000);
setTimeout(function(){
	s5.classList.add('hide');
},45000);
setTimeout(function(){
	s6.classList.add('hide');
},50000);
setTimeout(function(){
	s7.classList.add('hide');
},55000);
setTimeout(function(){
	s8.classList.add('hide');
},60000);